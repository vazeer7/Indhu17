from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select
import time

driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))
driver.get("https://www.tutorialspoint.com/selenium/selenium_automation_practice.htm")
driver.implicitly_wait(10)
dropDown = driver.find_element(By.XPATH, "//select[@name='continents']")
select = Select(dropDown)
select.select_by_visible_text("Antartica")

alloptions = select.options
for ele in alloptions:
    print(ele.text)
    if (ele.text == "Antartica"):
        ele.click()
        break

print(select.is_multiple)

#interview ques - how do we handle dropdown without select 
options = driver.find_elements(By.XPATH, "//select[@name='continents']/option")
for ele in options:
    print(ele.text)
    if (ele.text == "Antartica"):
        ele.click()
        break

def select_values(dropdownOptionsList, values):
    print(len(dropdownOptionsList))
    for ele in dropdownOptionsList:
        print(ele.text)
        if (ele.text == values):
            ele.click()
            break

select_values(options, "North America")

time.sleep(8)