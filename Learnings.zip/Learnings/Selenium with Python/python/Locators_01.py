from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select
import time
driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))

driver.get("https://rahulshettyacademy.com/angularpractice/")
driver.implicitly_wait(10)
driver.find_element(By.CSS_SELECTOR, '.form-control.ng-untouched.ng-pristine.ng-invalid').send_keys("Indhu")
driver.find_element(By.CSS_SELECTOR, "input[name='email']").send_keys("abc@gmail.com")
driver.find_element(By.CSS_SELECTOR, "input[id*='exampleInput']").send_keys("123456")
driver.find_element(By.CSS_SELECTOR, "input.form-check-input[id='exampleCheck1']").click()
dropdown = driver.find_element(By.XPATH, "//*[@id='exampleFormControlSelect1']")
select = Select(dropdown)
select.select_by_visible_text("Female")
select.select_by_index(0)
print(select.is_multiple)
time.sleep(10)