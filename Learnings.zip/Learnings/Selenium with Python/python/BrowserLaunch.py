from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager

# from selenium.webdriver.firefox.service import Service
# from webdriver_manager.firefox import GeckoDriverManager

driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))

# driver = webdriver.Firefox(service=Service(GeckoDriverManager().install()))

driver.get("https://www.facebook.com")


