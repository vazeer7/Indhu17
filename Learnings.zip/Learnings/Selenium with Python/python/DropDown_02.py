from selenium import webdriver
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
import time

driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))
driver.get("https://www.jqueryscript.net/demo/Drop-Down-Combo-Tree/")
driver.implicitly_wait(10)

def select_values(options_list, value):
    if not value[0]=='all':
        for ele in options_list:
            print(ele.text)
            for k in range(len(value)):
                if ele.text == value[k]:
                    ele.click()
                    break
    else:
        try:
            for ele in options_list:
                ele.click()
        except Exception as e:
            print(e)

driver.find_element(By.CSS_SELECTOR, "input[id='justAnInputBox']").click()
time.sleep(3)
multiSelectionOptions = driver.find_elements(By.CSS_SELECTOR, "span.comboTreeItemTitle")

def select_value(optionlists, value):
    for ele in optionlists:
        if not ele.text == '':
            print(ele.text)
            continue
        if ele.text == value:
            ele.click()
            print("element clicked!!", ele.text)
            break

# select_value(multiSelectionOptions, "choice 4")
# select_value(multiSelectionOptions, "choice 6")
# select_value(multiSelectionOptions, "choice 2")

# value_list = ["choice 4", "choice 2", "choice 6"]
# value_list = ["choice 1"]
value_list = ["all"]
select_values(multiSelectionOptions, value_list)

# for ele in multiSelectionOptions:
#     if not ele.text == '':
#         print(ele.text)
#         continue
#     if ele.text == "choice 4":
#         ele.click()
#         print("element clicked!!", ele.text)
#         break

time.sleep(10)

